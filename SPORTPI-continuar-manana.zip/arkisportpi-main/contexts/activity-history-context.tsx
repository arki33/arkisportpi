'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { usePiAuth } from '@/contexts/pi-auth-context';

export interface CompletedActivity {
  id: string;
  type: 'walk' | 'run' | 'cycle' | 'swim' | 'hike' | 'gym' | 'football' | 'basketball' | 'yoga' | 'other';
  distance: number;
  duration: number;
  avgSpeed: number;
  maxSpeed: number;
  elevationGain: number;
  caloriesKcal: number;
  /** Always zero until a server-side anti-cheat and reward ledger is implemented. */
  piEarned: number;
  startTime: Date;
  endTime: Date;
  gpsRoute: Array<{ lat: number; lng: number; timestamp: number }>;
  image?: string;
}

interface ActivityHistoryContextType {
  activities: CompletedActivity[];
  addActivity: (activity: CompletedActivity) => void;
  getActivityById: (id: string) => CompletedActivity | undefined;
  deleteActivity: (id: string) => void;
}

const ActivityHistoryContext = createContext<ActivityHistoryContextType | undefined>(undefined);

export function ActivityHistoryProvider({ children }: { children: ReactNode }) {
  const { user, accessToken } = usePiAuth();
  const [activities, setActivities] = useState<CompletedActivity[]>([]);
  const [loadedForUid, setLoadedForUid] = useState<string | null>(null);
  const storageKey = user?.uid ? `sportpi:activities:${user.uid}` : null;

  useEffect(() => {
    if (!storageKey) {
      setActivities([]);
      setLoadedForUid(null);
      return;
    }
    try {
      const raw = localStorage.getItem(storageKey);
      const parsed = raw ? JSON.parse(raw) as CompletedActivity[] : [];
      setActivities(parsed.map((activity) => ({
        ...activity,
        startTime: new Date(activity.startTime),
        endTime: new Date(activity.endTime),
      })));
    } catch {
      setActivities([]);
    }
    setLoadedForUid(user!.uid);
  }, [storageKey, user]);

  useEffect(() => {
    if (!accessToken || !user?.uid) return;
    let cancelled = false;
    fetch('/api/activities', { headers: { Authorization: `Bearer ${accessToken}` }, cache: 'no-store' })
      .then(async (response) => {
        if (!response.ok) throw new Error('No se pudo sincronizar el historial remoto.');
        return response.json();
      })
      .then((data) => {
        if (cancelled || !Array.isArray(data.activities)) return;
        const remote = data.activities.map((activity: CompletedActivity) => ({
          ...activity,
          startTime: new Date(activity.startTime),
          endTime: new Date(activity.endTime),
          piEarned: 0,
        }));
        setActivities((local) => {
          const byId = new Map(local.map((activity) => [activity.id, activity]));
          for (const activity of remote) byId.set(activity.id, activity);
          return Array.from(byId.values()).sort((a, b) => b.startTime.getTime() - a.startTime.getTime());
        });
      })
      .catch((error) => console.warn('SPORTPI: sincronización de actividades pendiente.', error));
    return () => { cancelled = true; };
  }, [accessToken, user?.uid]);

  useEffect(() => {
    if (!storageKey || loadedForUid !== user?.uid) return;
    try { localStorage.setItem(storageKey, JSON.stringify(activities)); }
    catch (error) { console.warn('No se pudo guardar el historial local de SPORTPI.', error); }
  }, [activities, storageKey, loadedForUid, user?.uid]);

  const addActivity = useCallback((activity: CompletedActivity) => {
    setActivities((prev) => [activity, ...prev]);
    if (accessToken) {
      void fetch('/api/activities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(activity),
      }).then(async (response) => {
        if (!response.ok) { const data = await response.json().catch(() => ({})); throw new Error(data.error || 'No se pudo guardar en el servidor.'); }
      }).catch((error) => console.warn('La actividad se conserva localmente, pero no se pudo sincronizar:', error));
    }
  }, [accessToken]);
  const getActivityById = useCallback((id: string) => activities.find((activity) => activity.id === id), [activities]);
  const deleteActivity = useCallback((id: string) => {
    setActivities((prev) => prev.filter((activity) => activity.id !== id));
    if (accessToken) void fetch('/api/activities', { method: 'DELETE', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` }, body: JSON.stringify({ id }) }).then((response) => { if (!response.ok) throw new Error('El servidor no pudo eliminar la actividad.'); }).catch((error) => console.warn('No se pudo sincronizar la eliminación de la actividad:', error));
  }, [accessToken]);
  const value = useMemo(() => ({ activities, addActivity, getActivityById, deleteActivity }), [activities, addActivity, getActivityById, deleteActivity]);

  return <ActivityHistoryContext.Provider value={value}>{children}</ActivityHistoryContext.Provider>;
}

export function useActivityHistory() {
  const context = useContext(ActivityHistoryContext);
  if (!context) throw new Error('useActivityHistory debe utilizarse dentro de ActivityHistoryProvider');
  return context;
}

"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { initializePiSdk, type PiPaymentDTO, type PiSdk, type PiUser } from "@/lib/pi-sdk";

type AuthStatus = "loading" | "ready" | "authenticating" | "authenticated" | "error";
type PiAuthContextValue = {
  status: AuthStatus;
  isAuthenticated: boolean;
  user: PiUser | null;
  accessToken: string | null;
  sdk: PiSdk | null;
  error: string | null;
  login: () => Promise<void>;
  logout: () => void;
  reinitialize: () => Promise<void>;
};

const PiAuthContext = createContext<PiAuthContextValue | undefined>(undefined);

async function postWithToken(path: string, token: string, body: unknown) {
  const response = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Error del servidor (${response.status})`);
  return data;
}

export function PiAuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AuthStatus>("loading");
  const [user, setUser] = useState<PiUser | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [sdk, setSdk] = useState<PiSdk | null>(null);
  const [error, setError] = useState<string | null>(null);
  const accessTokenRef = useRef<string | null>(null);
  const pendingIncompletePaymentRef = useRef<PiPaymentDTO | null>(null);

  const reinitialize = useCallback(async () => {
    setStatus("loading");
    setError(null);
    try {
      const instance = await initializePiSdk();
      setSdk(instance);
      setStatus("ready");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No se pudo inicializar Pi SDK.");
      setStatus("error");
    }
  }, []);

  useEffect(() => { void reinitialize(); }, [reinitialize]);

  const handleIncompletePayment = useCallback(async (payment: PiPaymentDTO) => {
    const token = accessTokenRef.current;
    if (!payment?.identifier || !payment.transaction?.txid) return;
    if (!token) { pendingIncompletePaymentRef.current = payment; return; }
    try {
      await postWithToken("/api/payments/recover", token, {
        paymentId: payment.identifier,
        txid: payment.transaction.txid,
      });
    } catch (cause) {
      console.error("No se pudo recuperar el pago Pi pendiente:", cause);
    }
  }, []);

  const login = useCallback(async () => {
    if (!sdk) throw new Error("El SDK de Pi todavía no está preparado.");
    setStatus("authenticating");
    setError(null);
    try {
      const auth = await sdk.authenticate(["username", "payments", "wallet_address"], handleIncompletePayment);
      const verified = await postWithToken("/api/auth/verify", auth.accessToken, {});
      accessTokenRef.current = auth.accessToken;
      setAccessToken(auth.accessToken);
      setUser(verified.user as PiUser);
      if (pendingIncompletePaymentRef.current) {
        const pending = pendingIncompletePaymentRef.current;
        pendingIncompletePaymentRef.current = null;
        await handleIncompletePayment(pending);
      }
      setStatus("authenticated");
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "No se pudo iniciar sesión con Pi.";
      setError(message);
      setStatus("ready");
      throw cause;
    }
  }, [sdk, handleIncompletePayment]);

  const logout = useCallback(() => {
    accessTokenRef.current = null;
    pendingIncompletePaymentRef.current = null;
    setAccessToken(null);
    setUser(null);
    setError(null);
    setStatus(sdk ? "ready" : "loading");
  }, [sdk]);

  const value = useMemo(() => ({
    status, isAuthenticated: status === "authenticated", user, accessToken, sdk, error, login, logout, reinitialize,
  }), [status, user, accessToken, sdk, error, login, logout, reinitialize]);

  return <PiAuthContext.Provider value={value}>{children}</PiAuthContext.Provider>;
}

export function usePiAuth() {
  const context = useContext(PiAuthContext);
  if (!context) throw new Error("usePiAuth debe utilizarse dentro de PiAuthProvider.");
  return context;
}

'use client';

import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trophy, Users, PlusCircle, RefreshCw } from 'lucide-react';
import { usePiAuth } from '@/contexts/pi-auth-context';

const toLocalDateTimeInput = (date: Date) => new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);

type Challenge = {
  id: string; title: string; description: string | null; activityType: string; metric: string;
  targetValue: number; startsAt: string; endsAt: string; creator: string; participantCount: number; joined: boolean;
};

export default function ChallengesScreen() {
  const { accessToken, isAuthenticated } = usePiAuth();
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [activityType, setActivityType] = useState('any');
  const [metric, setMetric] = useState('distance');
  const [targetValue, setTargetValue] = useState('10');
  const [startsAt, setStartsAt] = useState(() => toLocalDateTimeInput(new Date()));
  const [endsAt, setEndsAt] = useState(() => toLocalDateTimeInput(new Date(Date.now() + 7 * 86400000)));

  const load = useCallback(async () => {
    if (!accessToken) return;
    setLoading(true); setError('');
    try {
      const response = await fetch('/api/challenges', { headers: { Authorization: `Bearer ${accessToken}` }, cache: 'no-store' });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'No se pudieron cargar los desafíos.');
      setChallenges(data.challenges || []);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Error de conexión.'); }
    finally { setLoading(false); }
  }, [accessToken]);

  useEffect(() => { void load(); }, [load]);

  const send = async (body: Record<string, unknown>) => {
    if (!accessToken) return;
    const response = await fetch('/api/challenges', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` }, body: JSON.stringify(body) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'No se pudo completar la operación.');
    return data;
  };

  const join = async (challengeId: string) => {
    try { await send({ action: 'join', challengeId }); setNotice('Te has unido al desafío.'); await load(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'No se pudo unir al desafío.'); }
  };

  const create = async (event: FormEvent) => {
    event.preventDefault(); setError('');
    try {
      await send({ action: 'create', title, description, activityType, metric, targetValue: Number(targetValue), startsAt: new Date(startsAt).toISOString(), endsAt: new Date(endsAt).toISOString() });
      setNotice('Desafío creado y publicado.'); setShowCreate(false); setTitle(''); setDescription(''); await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'No se pudo crear el desafío.'); }
  };

  const metricLabel = (value: string) => (({ distance: 'km', duration: 'segundos', steps: 'pasos', sessions: 'sesiones' }) as Record<string, string>)[value] || value;
  return (
    <div className="space-y-4 p-4">
      <div className="rounded-2xl bg-gradient-to-r from-primary to-secondary p-6 text-primary-foreground">
        <Trophy className="mb-2 h-8 w-8" />
        <h2 className="text-2xl font-bold">Retos SPORTPI</h2>
        <p className="text-sm opacity-80">Crea desafíos y compite con otros usuarios autenticados de Pi.</p>
      </div>
      {!isAuthenticated ? (
        <Card className="p-5"><h3 className="font-bold">Inicia sesión con Pi</h3><p className="mt-2 text-sm text-muted-foreground">Los desafíos compartidos necesitan identificar a los participantes mediante Pi Browser.</p></Card>
      ) : <>
        <div className="flex gap-2"><Button className="flex-1" onClick={() => setShowCreate((value) => !value)}><PlusCircle className="mr-2 h-4 w-4" />Crear desafío</Button><Button variant="outline" onClick={() => void load()} disabled={loading}><RefreshCw className="h-4 w-4" /></Button></div>
        {showCreate && <Card className="p-4"><form className="space-y-3" onSubmit={create}>
          <h3 className="font-bold">Nuevo desafío público</h3>
          <label className="block text-sm">Nombre<input className="mt-1 w-full rounded-md border bg-background p-2" required maxLength={80} value={title} onChange={(e) => setTitle(e.target.value)} /></label>
          <label className="block text-sm">Descripción<textarea className="mt-1 w-full rounded-md border bg-background p-2" maxLength={500} value={description} onChange={(e) => setDescription(e.target.value)} /></label>
          <div className="grid grid-cols-2 gap-2">
            <label className="text-sm">Deporte<select className="mt-1 w-full rounded-md border bg-background p-2" value={activityType} onChange={(e) => setActivityType(e.target.value)}><option value="any">Cualquier deporte</option><option value="walk">Caminar</option><option value="run">Correr</option><option value="cycle">Bicicleta</option><option value="swim">Natación</option><option value="hike">Senderismo</option><option value="gym">Gimnasio</option></select></label>
            <label className="text-sm">Objetivo<select className="mt-1 w-full rounded-md border bg-background p-2" value={metric} onChange={(e) => setMetric(e.target.value)}><option value="distance">Distancia (km)</option><option value="duration">Tiempo (segundos)</option><option value="steps">Pasos</option><option value="sessions">Sesiones</option></select></label>
          </div>
          <label className="block text-sm">Meta ({metricLabel(metric)})<input className="mt-1 w-full rounded-md border bg-background p-2" type="number" min="0.1" step="0.1" required value={targetValue} onChange={(e) => setTargetValue(e.target.value)} /></label>
          <div className="grid grid-cols-2 gap-2"><label className="text-sm">Inicio<input className="mt-1 w-full rounded-md border bg-background p-2" type="datetime-local" required value={startsAt} onChange={(e) => setStartsAt(e.target.value)} /></label><label className="text-sm">Fin<input className="mt-1 w-full rounded-md border bg-background p-2" type="datetime-local" required value={endsAt} onChange={(e) => setEndsAt(e.target.value)} /></label></div>
          <Button type="submit" className="w-full">Publicar desafío</Button>
        </form></Card>}
        {notice && <p className="text-sm text-green-700">{notice}</p>}{error && <p className="text-sm text-red-600">{error}</p>}
        {loading && <p className="text-sm text-muted-foreground">Cargando desafíos...</p>}
        {!loading && challenges.length === 0 && <Card className="p-5 text-sm text-muted-foreground">Todavía no hay desafíos públicos activos. Puedes crear el primero.</Card>}
        {challenges.map((challenge) => <Card key={challenge.id} className="space-y-3 p-4">
          <div className="flex items-start justify-between gap-2"><div><h3 className="font-bold">{challenge.title}</h3><p className="text-xs text-muted-foreground">Creado por {challenge.creator}</p></div><Trophy className="h-5 w-5 text-primary" /></div>
          {challenge.description && <p className="text-sm">{challenge.description}</p>}
          <div className="grid grid-cols-2 gap-2 text-sm"><div className="rounded-lg bg-muted p-2"><p className="text-xs text-muted-foreground">Objetivo</p><strong>{challenge.targetValue} {metricLabel(challenge.metric)}</strong></div><div className="rounded-lg bg-muted p-2"><p className="text-xs text-muted-foreground">Participantes</p><strong className="flex items-center gap-1"><Users className="h-4 w-4" />{challenge.participantCount}</strong></div></div>
          <p className="text-xs text-muted-foreground">{challenge.activityType === 'any' ? 'Todos los deportes' : challenge.activityType} · Hasta {new Date(challenge.endsAt).toLocaleDateString('es-ES')}</p>
          <Button className="w-full" variant={challenge.joined ? 'outline' : 'default'} disabled={challenge.joined} onClick={() => void join(challenge.id)}>{challenge.joined ? 'Ya participas' : 'Unirme al desafío'}</Button>
        </Card>)}
        <Card className="p-4"><p className="text-xs text-muted-foreground">La participación ya se registra con la identidad Pi. El progreso y las clasificaciones solo deben sumar entrenamientos verificados por el servidor; no se aceptan pasos ni kilómetros del navegador como prueba antifraude.</p></Card>
      </>}
    </div>
  );
}

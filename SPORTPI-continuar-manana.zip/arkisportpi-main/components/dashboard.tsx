'use client';

import { Card } from '@/components/ui/card';
import { useLanguage } from '@/contexts/language-context';
import { useActivityHistory } from '@/contexts/activity-history-context';
import { Activity, MapPinned, ShieldCheck, Trophy } from 'lucide-react';
import StepCounter from '@/components/step-counter';

export default function Dashboard() {
  const { t } = useLanguage();
  const { activities } = useActivityHistory();
  const totalDistance = activities.reduce((sum, activity) => sum + activity.distance, 0);
  const totalDuration = activities.reduce((sum, activity) => sum + activity.duration, 0);
  const totalCalories = activities.reduce((sum, activity) => sum + (activity.caloriesKcal || 0), 0);

  return (
    <div className="space-y-4 p-4">
      <Card className="rounded-2xl bg-gradient-to-br from-primary to-secondary p-6 text-primary-foreground">
        <p className="text-sm opacity-90">SPORTPI</p>
        <h2 className="mt-1 text-2xl font-bold">{t('tagline')}</h2>
        <p className="mt-2 text-sm opacity-80">Registra tus actividades reales y consulta tu progreso.</p>
      </Card>

      <StepCounter />

      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4">
          <Activity className="mb-2 h-5 w-5 text-primary" />
          <p className="text-2xl font-bold">{activities.length}</p>
          <p className="text-xs text-muted-foreground">Actividades guardadas en este dispositivo</p>
        </Card>
        <Card className="p-4">
          <MapPinned className="mb-2 h-5 w-5 text-primary" />
          <p className="text-2xl font-bold">{totalDistance.toFixed(2)} km</p>
          <p className="text-xs text-muted-foreground">Distancia registrada</p>
        </Card>
        <Card className="p-4">
          <Trophy className="mb-2 h-5 w-5 text-primary" />
          <p className="text-2xl font-bold">{Math.floor(totalDuration / 60)} min</p>
          <p className="text-xs text-muted-foreground">Tiempo acumulado</p>
        </Card>
        <Card className="p-4">
          <Trophy className="mb-2 h-5 w-5 text-primary" />
          <p className="text-2xl font-bold">{totalCalories.toLocaleString('es-ES')}</p>
          <p className="text-xs text-muted-foreground">Calorías estimadas</p>
        </Card>
        <Card className="p-4">
          <ShieldCheck className="mb-2 h-5 w-5 text-primary" />
          <p className="text-sm font-bold">Sin saldo ficticio</p>
          <p className="text-xs text-muted-foreground">Las recompensas requieren validación del servidor.</p>
        </Card>
      </div>

      <Card className="p-4">
        <h3 className="mb-2 font-bold">Próximas funciones</h3>
        <p className="text-sm text-muted-foreground">Estamos preparando sincronización entre dispositivos, desafíos globales, clasificación compartida y un sistema de recompensas con validación antifraude. Los datos locales no se presentan como estadísticas globales.</p>
      </Card>
    </div>
  );
}

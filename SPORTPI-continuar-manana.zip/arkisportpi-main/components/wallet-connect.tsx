'use client';

import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { Wallet, ShieldCheck, Copy } from 'lucide-react';

export default function WalletConnect() {
  const { user } = usePiAuth();
  const address = user?.wallet_address;

  return (
    <Card className="p-5 space-y-3">
      <div className="flex items-center gap-3">
        <Wallet className="h-6 w-6 text-primary" />
        <div>
          <h3 className="font-bold">Cuenta Pi vinculada</h3>
          <p className="text-xs text-muted-foreground">Identidad confirmada mediante Pi Platform API</p>
        </div>
        <Badge className="ml-auto"><ShieldCheck className="mr-1 h-3 w-3" /> Verificada</Badge>
      </div>
      <div className="rounded-lg bg-muted/40 p-3">
        <p className="mb-1 text-xs text-muted-foreground">Usuario Pi</p>
        <p className="font-semibold">{user?.username ? `@${user.username}` : 'Nombre no compartido'}</p>
      </div>
      <div className="rounded-lg bg-muted/40 p-3">
        <p className="mb-1 text-xs text-muted-foreground">Dirección pública de wallet</p>
        {address ? (
          <div className="flex items-center gap-2">
            <code className="min-w-0 flex-1 break-all text-xs">{address}</code>
            <button aria-label="Copiar dirección" onClick={() => void navigator.clipboard?.writeText(address)} className="rounded p-2 hover:bg-muted"><Copy className="h-4 w-4" /></button>
          </div>
        ) : <p className="text-sm text-muted-foreground">No disponible. Comprueba que aceptaste el permiso wallet_address en Pi.</p>}
      </div>
      <p className="text-xs text-muted-foreground">SPORTPI no solicita tu frase semilla ni tu clave privada. Nunca las introduzcas en la aplicación.</p>
    </Card>
  );
}

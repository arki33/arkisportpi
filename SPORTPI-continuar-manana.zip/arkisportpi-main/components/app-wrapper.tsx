"use client";

import type { ReactNode } from "react";
import { PiAuthProvider, usePiAuth } from "@/contexts/pi-auth-context";
import { ActivityHistoryProvider } from "@/contexts/activity-history-context";
import { LanguageProvider } from "@/contexts/language-context";
import { AuthLoadingScreen } from "./auth-loading-screen";

function AppContent({ children }: { children: ReactNode }) {
  const { isAuthenticated } = usePiAuth();
  if (!isAuthenticated) return <AuthLoadingScreen />;
  return <>{children}</>;
}

export function AppWrapper({ children }: { children: ReactNode }) {
  return (
    <LanguageProvider>
      <PiAuthProvider>
        <ActivityHistoryProvider>
          <AppContent>{children}</AppContent>
        </ActivityHistoryProvider>
      </PiAuthProvider>
    </LanguageProvider>
  );
}

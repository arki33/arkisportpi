'use client';

import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguage } from '@/contexts/language-context';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { Settings, LogOut, Award, TrendingUp } from 'lucide-react';
import WalletConnect from '@/components/wallet-connect';
import PiPaymentShop from '@/components/pi-payment-shop';
import { useActivityHistory } from '@/contexts/activity-history-context';

export default function ProfileScreen() {
  const { t } = useLanguage();
  const { user: piUser, logout } = usePiAuth();
  const { activities } = useActivityHistory();
  const totalDistance = activities.reduce((sum, activity) => sum + activity.distance, 0);
  const totalDuration = activities.reduce((sum, activity) => sum + activity.duration, 0);
  const user = {
    name: piUser?.username ? `@${piUser.username}` : 'Usuario Pi',
    joinDate: 'Cuenta Pi verificada',
  };
  const now = new Date();
  const weekly = Array.from({ length: 7 }, (_, index) => {
    const day = new Date(now); day.setHours(0, 0, 0, 0); day.setDate(now.getDate() - (6 - index));
    const distance = activities.filter((activity) => new Date(activity.startTime).toDateString() === day.toDateString()).reduce((sum, activity) => sum + activity.distance, 0);
    return { day, distance };
  });
  const maxWeeklyDistance = Math.max(1, ...weekly.map((item) => item.distance));

  const stats = [
    { label: 'Activities', value: String(activities.length), icon: '🏃' },
    { label: 'Distance', value: totalDistance.toFixed(2), suffix: 'km', icon: '📍' },
    { label: 'Activity Time', value: String(Math.floor(totalDuration / 60)), suffix: 'min', icon: '⏱️' },
    { label: 'Pi Rewards', value: 'Pending', icon: '🪙' },
  ];

  const achievements = [
    { id: 1, name: 'Primer entrenamiento', description: 'Registra tu primera actividad', icon: '🏃', earned: activities.length > 0 },
    { id: 2, name: '25 kilómetros', description: 'Acumula 25 km registrados', icon: '📍', earned: totalDistance >= 25 },
    { id: 3, name: '10 entrenamientos', description: 'Registra diez actividades', icon: '🔥', earned: activities.length >= 10 },
    { id: 4, name: '50 kilómetros', description: 'Acumula 50 km registrados', icon: '🏅', earned: totalDistance >= 50 },
  ];


  return (
    <div className="p-4 space-y-4">
      {/* Profile Header */}
      <Card className="bg-gradient-to-br from-primary to-secondary text-primary-foreground p-6 rounded-2xl">
        <div className="flex justify-between items-start mb-4">
          <div>
            <div className="text-5xl mb-2">💪</div>
            <h2 className="text-2xl font-bold">{user.name}</h2>
            <p className="text-sm opacity-80">Identidad Pi verificada</p>
            <p className="text-xs opacity-60 mt-2">Member since {user.joinDate}</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">SPORTPI</div>
            <p className="text-sm opacity-80">Miembro</p>
          </div>
        </div>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat, idx) => (
          <Card key={idx} className="p-4 text-center">
            <span className="text-3xl">{stat.icon}</span>
            <p className="font-bold mt-2 text-lg">
              {stat.value}
              {stat.suffix && <span className="text-sm ml-1">{stat.suffix}</span>}
            </p>
            <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="achievements" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="wallet">Wallet</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        {/* Achievements Tab */}
        <TabsContent value="achievements" className="space-y-3 mt-4">
          <div className="grid grid-cols-2 gap-3">
            {achievements.map((achievement) => {
              const isEarned = achievement.earned;
              return (
                <Card
                  key={achievement.id}
                  className={`p-4 text-center transition-all ${
                    isEarned
                      ? 'bg-accent/10 border-accent/50'
                      : 'bg-muted/30 opacity-50'
                  }`}
                >
                  <span className="text-3xl block mb-2">{achievement.icon}</span>
                  <p className="font-bold text-sm">{achievement.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {achievement.description}
                  </p>
                  {isEarned && (
                    <Badge className="mt-2 bg-accent text-accent-foreground">Earned</Badge>
                  )}
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Activity Tab */}
        <TabsContent value="activity" className="space-y-3 mt-4">
          <Card className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h3 className="font-bold">Resumen de los últimos siete días</h3>
            </div>
            {weekly.map(({ day, distance }) => (
              <div key={day.toISOString()} className="space-y-1 mt-3">
                <div className="flex justify-between text-sm"><span>{day.toLocaleDateString('es-ES', { weekday: 'long' })}</span><strong>{distance.toFixed(2)} km</strong></div>
                <div className="h-2 w-full rounded bg-muted"><div className="h-2 rounded bg-primary" style={{ width: `${(distance / maxWeeklyDistance) * 100}%` }} /></div>
              </div>
            ))}
            <p className="mt-3 text-xs text-muted-foreground">Resumen calculado a partir de tus actividades guardadas; no incluye datos ficticios.</p>
          </Card>
        </TabsContent>

        {/* Wallet Tab */}
        <TabsContent value="wallet" className="space-y-3 mt-4">
          <WalletConnect />
          <PiPaymentShop />
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-3 mt-4">
          <Card className="p-4">
            <button className="w-full flex items-center justify-between p-3 hover:bg-muted rounded-lg transition">
              <span className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Notifications
              </span>
              <Badge variant="outline">On</Badge>
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-muted rounded-lg transition">
              <span className="flex items-center gap-2">
                <Award className="w-5 h-5" />
                Rewards Settings
              </span>
              <span className="text-muted-foreground">&gt;</span>
            </button>
            <button onClick={logout} className="w-full flex items-center justify-between p-3 hover:bg-muted rounded-lg transition border-t text-destructive">
              <span className="flex items-center gap-2"><LogOut className="w-5 h-5" /> Cerrar sesión Pi</span>
              <span>&gt;</span>
            </button>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Footprints, Smartphone } from 'lucide-react';

const DAILY_GOAL = 8000;
const todayKey = () => new Date().toLocaleDateString('en-CA');

type MotionPermissionEvent = typeof DeviceMotionEvent & { requestPermission?: () => Promise<'granted' | 'denied'> };

export default function StepCounter() {
  const [steps, setSteps] = useState(0);
  const [enabled, setEnabled] = useState(false);
  const [supported, setSupported] = useState(true);
  const [message, setMessage] = useState('Activa el sensor del teléfono para estimar tus pasos.');
  const lastPeakAt = useRef(0);
  const previousMagnitude = useRef(0);

  useEffect(() => {
    const key = `sportpi:steps:${todayKey()}`;
    const saved = Number(localStorage.getItem(key) || 0);
    setSteps(Number.isFinite(saved) ? saved : 0);
    setSupported(typeof window !== 'undefined' && 'DeviceMotionEvent' in window);
  }, []);

  const onMotion = useCallback((event: DeviceMotionEvent) => {
    const acceleration = event.accelerationIncludingGravity;
    if (!acceleration) return;
    const x = acceleration.x ?? 0;
    const y = acceleration.y ?? 0;
    const z = acceleration.z ?? 0;
    const magnitude = Math.sqrt(x * x + y * y + z * z);
    const delta = Math.abs(magnitude - previousMagnitude.current);
    const now = Date.now();
    // Conservative peak detection; browser motion data is an estimate, not a certified pedometer.
    if (delta > 1.35 && now - lastPeakAt.current > 300) {
      lastPeakAt.current = now;
      setSteps((current) => {
        const next = current + 1;
        localStorage.setItem(`sportpi:steps:${todayKey()}`, String(next));
        return next;
      });
    }
    previousMagnitude.current = magnitude;
  }, []);

  useEffect(() => {
    if (!enabled) return;
    window.addEventListener('devicemotion', onMotion);
    return () => window.removeEventListener('devicemotion', onMotion);
  }, [enabled, onMotion]);

  const activate = async () => {
    if (!('DeviceMotionEvent' in window)) {
      setSupported(false);
      setMessage('Este navegador no permite leer el sensor de movimiento.');
      return;
    }
    try {
      const motion = DeviceMotionEvent as MotionPermissionEvent;
      if (typeof motion.requestPermission === 'function') {
        const permission = await motion.requestPermission();
        if (permission !== 'granted') throw new Error('Permiso del sensor denegado.');
      }
      setEnabled(true);
      setMessage('Contador activo mientras SPORTPI permanezca abierto.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'No se pudo activar el sensor.');
    }
  };

  const progress = Math.min(100, (steps / DAILY_GOAL) * 100);
  return (
    <Card className="space-y-3 p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2"><Footprints className="h-5 w-5 text-primary" /><h3 className="font-bold">Pasos de hoy</h3></div>
        <span className="text-xs text-muted-foreground">Objetivo {DAILY_GOAL.toLocaleString('es-ES')}</span>
      </div>
      <div className="flex items-end gap-2"><span className="text-3xl font-bold tabular-nums">{steps.toLocaleString('es-ES')}</span><span className="pb-1 text-sm text-muted-foreground">pasos</span></div>
      <div className="h-2 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${progress}%` }} /></div>
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-muted-foreground">{message}</p>
        {!enabled && supported && <Button size="sm" onClick={activate}><Smartphone className="mr-1 h-4 w-4" />Activar</Button>}
      </div>
      {!supported && <p className="text-xs text-amber-700">El contador requiere un dispositivo y navegador compatibles con Device Motion.</p>}
      <p className="text-[11px] text-muted-foreground">Estimación por sensor de movimiento; no equivale a los datos de un reloj o podómetro certificado. Puede dejar de contar si el navegador queda en segundo plano.</p>
    </Card>
  );
}

'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PI_PRODUCTS } from '@/lib/pi-products';
import { LoaderCircle, ShoppingBag, ShieldCheck } from 'lucide-react';

export default function PiPaymentShop() {
  const { sdk, accessToken, isAuthenticated } = usePiAuth();
  const [busyProduct, setBusyProduct] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const post = async (path: string, body: unknown) => {
    if (!accessToken) throw new Error('La sesión Pi ha caducado. Vuelve a iniciar sesión.');
    const response = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify(body),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Error ${response.status}`);
    return data;
  };

  const buy = async (productId: string) => {
    if (!sdk || !isAuthenticated) return;
    setBusyProduct(productId);
    setMessage(null);
    setError(null);
    try {
      const prepared = await post('/api/payments/prepare', { productId });
      sdk.createPayment({
        amount: prepared.product.amount,
        memo: `SPORTPI: ${prepared.product.name}`,
        metadata: { sportpiOrderId: prepared.orderId, sportpiProductId: prepared.product.id },
      }, {
        onReadyForServerApproval: async (paymentId) => {
          await post('/api/payments/approve', { paymentId });
        },
        onReadyForServerCompletion: async (paymentId, txid) => {
          try {
            await post('/api/payments/complete', { paymentId, txid });
            setMessage(`Pago confirmado por Pi. Producto ${prepared.product.name} registrado en tu cuenta.`);
          } catch (cause) {
            setError(cause instanceof Error ? cause.message : 'No se pudo completar el pago en SPORTPI.');
            throw cause;
          } finally {
            setBusyProduct(null);
          }
        },
        onCancel: () => {
          setMessage('Has cancelado el pago. No se ha entregado ningún producto.');
          setBusyProduct(null);
        },
        onError: (cause) => {
          setError(cause.message || 'Pi ha informado de un error en el pago.');
          setBusyProduct(null);
        },
      });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'No se pudo iniciar el pago.');
      setBusyProduct(null);
    }
  };

  return (
    <Card className="space-y-3 p-5">
      <div className="flex items-center gap-2"><ShoppingBag className="h-5 w-5 text-primary" /><h3 className="font-bold">Tienda SPORTPI</h3><Badge variant="outline" className="ml-auto">Pi Payments</Badge></div>
      <div className="flex items-start gap-2 rounded-lg bg-muted/40 p-3 text-xs text-muted-foreground"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" /> Los importes se determinan en el servidor. Un producto solo se concede después de que Pi confirme el pago y SPORTPI registre la compra.</div>
      {PI_PRODUCTS.length === 0 ? (
        <p className="text-sm text-muted-foreground">Todavía no hay productos ni precios aprobados para vender. El catálogo se configura en <code>lib/pi-products.ts</code> antes de activar los cobros.</p>
      ) : PI_PRODUCTS.map((product) => (
        <div key={product.id} className="flex items-center gap-3 rounded-lg border p-3">
          <div className="min-w-0 flex-1"><p className="font-semibold">{product.name}</p><p className="text-xs text-muted-foreground">{product.description}</p></div>
          <div className="text-right"><p className="font-bold">{product.amount} π</p><Button size="sm" onClick={() => void buy(product.id)} disabled={busyProduct !== null}>{busyProduct === product.id ? <LoaderCircle className="h-4 w-4 animate-spin" /> : 'Comprar'}</Button></div>
        </div>
      ))}
      {message && <p role="status" className="text-sm text-green-700">{message}</p>}
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
    </Card>
  );
}

'use client';

import { useCallback, useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Medal, Users, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';

type Entry = { username: string; distanceKm: number; durationSec: number; activities: number };
export default function LeaderboardScreen() {
  const { accessToken, isAuthenticated } = usePiAuth();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const load = useCallback(async () => {
    if (!accessToken) return;
    setLoading(true); setError('');
    try {
      const response = await fetch('/api/leaderboard', { headers: { Authorization: `Bearer ${accessToken}` }, cache: 'no-store' });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'No se pudo cargar la clasificación.');
      setEntries(data.leaderboard || []);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Error de conexión.'); }
    finally { setLoading(false); }
  }, [accessToken]);
  useEffect(() => { void load(); }, [load]);
  return (
    <div className="space-y-4 p-4">
      <div className="rounded-2xl bg-gradient-to-r from-primary to-secondary p-6 text-primary-foreground"><Medal className="mb-2 h-8 w-8" /><h2 className="text-2xl font-bold">Clasificación SPORTPI</h2><p className="text-sm opacity-80">Ranking de la comunidad Pi.</p></div>
      {!isAuthenticated ? <Card className="p-5"><h3 className="font-bold">Inicia sesión con Pi</h3><p className="mt-2 text-sm text-muted-foreground">La clasificación muestra únicamente usuarios autenticados con Pi.</p></Card> : <>
        <div className="flex justify-end"><Button variant="outline" size="sm" onClick={() => void load()} disabled={loading}><RefreshCw className="mr-2 h-4 w-4" />Actualizar</Button></div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        {loading && <p className="text-sm text-muted-foreground">Cargando clasificación...</p>}
        {!loading && entries.length === 0 && <Card className="space-y-2 p-5"><Users className="h-7 w-7 text-primary" /><h3 className="font-bold">Todavía no hay resultados verificados</h3><p className="text-sm text-muted-foreground">Las actividades aparecerán cuando el servidor haya comprobado su validez. No se muestran cuentas ficticias ni entrenamientos sin verificar.</p></Card>}
        {entries.map((entry, index) => <Card key={`${entry.username}-${index}`} className="flex items-center justify-between gap-3 p-4"><div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-muted font-bold">{index + 1}</span><div><p className="font-semibold">{entry.username}</p><p className="text-xs text-muted-foreground">{entry.activities} actividades verificadas</p></div></div><div className="text-right"><p className="font-bold">{entry.distanceKm.toFixed(2)} km</p><p className="text-xs text-muted-foreground">distancia</p></div></Card>)}
      </>}
    </div>
  );
}

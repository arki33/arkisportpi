'use client';

import { useState, useEffect, useRef } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/language-context';
import { useActivityHistory } from '@/contexts/activity-history-context';
import { MapPin, Play, Pause, Check, Gauge, Zap, Clock, AlertCircle } from 'lucide-react';
import { GPSTracker, GPSCoordinate } from '@/lib/gps-tracker';
import SatelliteRouteMap from '@/components/satellite-route-map';

interface GPSPoint {
  lat: number;
  lng: number;
  timestamp: number;
  elevation: number;
}

interface ActivityStats {
  distance: number;
  time: number;
  avgSpeed: number;
  currentSpeed: number;
  maxSpeed: number;
  elevation: number;
  elevationGain: number;
  piEarned: number;
}

export default function ActivityTracker() {
  const { t } = useLanguage();
  const { addActivity } = useActivityHistory();
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [activityType, setActivityType] = useState<'walk' | 'run' | 'cycle' | 'swim' | 'hike' | 'gym' | 'football' | 'basketball' | 'yoga' | 'other'>('run');
  const [manualDistance, setManualDistance] = useState('');
  const [bodyWeight, setBodyWeight] = useState('70');
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [stats, setStats] = useState<ActivityStats>({
    distance: 0, time: 0, avgSpeed: 0, currentSpeed: 0, maxSpeed: 0,
    elevation: 0, elevationGain: 0, piEarned: 0,
  });
  const [gpsPoints, setGpsPoints] = useState<GPSPoint[]>([]);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const startTimeRef = useRef<number | null>(null);
  const pausedTimeRef = useRef<number>(0);
  const gpsTrackerRef = useRef<GPSTracker | null>(null);
  const gpsCoordinatesRef = useRef<GPSCoordinate[]>([]);
  const useRealGPS = true;
  const activityIcons = { walk: '🚶', run: '🏃', cycle: '🚴', swim: '🏊', hike: '🥾', gym: '🏋️', football: '⚽', basketball: '🏀', yoga: '🧘', other: '🏅' };
  const gpsRequired = ['walk', 'run', 'cycle', 'hike'].includes(activityType);
  const metValues: Record<string, number> = { walk: 3.5, run: 9.8, cycle: 7.5, swim: 8, hike: 6, gym: 5, football: 7, basketball: 6.5, yoga: 3, other: 4 };
  const estimatedCalories = Math.round((metValues[activityType] || 4) * Math.max(30, Math.min(250, Number(bodyWeight) || 70)) * (stats.time / 3600));

  const onGpsCoordinate = (coord: GPSCoordinate) => {
    // Reject low-accuracy fixes and implausible jumps instead of fabricating route data.
    if (coord.accuracy > 50) return;
    const previous = gpsCoordinatesRef.current[gpsCoordinatesRef.current.length - 1];
    if (previous) {
      const elapsedSeconds = Math.max((coord.timestamp - previous.timestamp) / 1000, 0.1);
      const segmentKm = GPSTracker.calculateDistance(previous.latitude, previous.longitude, coord.latitude, coord.longitude);
      if (segmentKm > 0.25 && elapsedSeconds < 5) return;
    }
    gpsCoordinatesRef.current.push(coord);
    const coordinates = gpsCoordinatesRef.current;
    const distance = GPSTracker.calculateTotalDistance(coordinates);
    const elapsed = startTimeRef.current ? Math.max(0, (Date.now() - startTimeRef.current + pausedTimeRef.current) / 1000) : 0;
    const avgSpeed = elapsed > 0 ? distance / (elapsed / 3600) : 0;
    const currentSpeed = coord.speed !== null ? Math.max(0, coord.speed * 3.6) : 0;
    const elevationGain = GPSTracker.calculateElevationGain(coordinates);
    const sampledCoordinates = coordinates.length <= 500
      ? coordinates
      : [coordinates[0], ...Array.from({ length: 498 }, (_, index) => coordinates[Math.round((index + 1) * (coordinates.length - 1) / 499)]), coordinates[coordinates.length - 1]];
    setGpsPoints(sampledCoordinates.map((point) => ({
      lat: point.latitude, lng: point.longitude, timestamp: point.timestamp, elevation: point.altitude ?? 0,
    })));
    setStats((previousStats) => ({
      ...previousStats,
      distance,
      time: Math.floor(elapsed),
      avgSpeed,
      currentSpeed,
      maxSpeed: Math.max(previousStats.maxSpeed, currentSpeed),
      elevation: coord.altitude ?? 0,
      elevationGain,
      // Pi rewards are never calculated or credited on the client.
      piEarned: 0,
    }));
  };

  const startGpsTracking = () => {
    if (!navigator.geolocation) {
      setGpsError('Este dispositivo o navegador no ofrece geolocalización. No se simularán datos.');
      setIsActive(false);
      return;
    }
    gpsTrackerRef.current?.stopTracking();
    gpsTrackerRef.current = new GPSTracker();
    gpsTrackerRef.current.startTracking(onGpsCoordinate, (message) => {
      setGpsError(message);
      setIsActive(false);
      gpsTrackerRef.current?.stopTracking();
    });
  };

  useEffect(() => {
    if (!isActive || isPaused || !startTimeRef.current) return;
    const timer = window.setInterval(() => {
      const elapsed = Math.max(0, (Date.now() - startTimeRef.current! + pausedTimeRef.current) / 1000);
      setStats((previous) => ({ ...previous, time: Math.floor(elapsed) }));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [isActive, isPaused]);

  const handleStart = () => {
    setGpsError(null);
    gpsCoordinatesRef.current = [];
    setGpsPoints([]);
    setStats({ distance: 0, time: 0, avgSpeed: 0, currentSpeed: 0, maxSpeed: 0, elevation: 0, elevationGain: 0, piEarned: 0 });
    pausedTimeRef.current = 0;
    startTimeRef.current = Date.now();
    setStartTime(new Date());
    setIsPaused(false);
    setIsActive(true);
    if (gpsRequired) startGpsTracking();
  };

  const handlePause = () => {
    if (startTimeRef.current) pausedTimeRef.current += Date.now() - startTimeRef.current;
    startTimeRef.current = null;
    gpsTrackerRef.current?.stopTracking();
    setIsPaused(true);
  };

  const handleResume = () => {
    startTimeRef.current = Date.now();
    setIsPaused(false);
    if (gpsRequired) startGpsTracking();
  };

  const handleFinish = () => {
    setIsActive(false);
    setIsPaused(false);
    gpsTrackerRef.current?.stopTracking();
    if ((gpsRequired ? gpsCoordinatesRef.current.length >= 2 : stats.time >= 10) && startTime) {
      addActivity({
        id: `activity_${Date.now()}`,
        type: activityType,
        distance: gpsRequired ? stats.distance : Math.max(0, Number(manualDistance) || 0),
        duration: stats.time,
        avgSpeed: gpsRequired ? stats.avgSpeed : Math.max(0, Number(manualDistance) || 0) / (stats.time / 3600 || 1),
        maxSpeed: gpsRequired ? stats.maxSpeed : Math.max(0, Number(manualDistance) || 0) / (stats.time / 3600 || 1),
        caloriesKcal: estimatedCalories,
        elevationGain: stats.elevationGain,
        piEarned: 0,
        startTime,
        endTime: new Date(),
        gpsRoute: gpsPoints.map(({ lat, lng, timestamp }) => ({ lat, lng, timestamp })),
      });
    } else {
      setGpsError(gpsRequired ? 'No hay suficientes puntos GPS válidos para guardar esta actividad.' : 'La actividad debe durar al menos 10 segundos.');
    }
    startTimeRef.current = null;
    pausedTimeRef.current = 0;
    setGpsPoints([]);
    gpsCoordinatesRef.current = [];
    setStartTime(null);
    setStats({ distance: 0, time: 0, avgSpeed: 0, currentSpeed: 0, maxSpeed: 0, elevation: 0, elevationGain: 0, piEarned: 0 });
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  // Satellite map backed by real GPS coordinates.
  const MapVisualization = () => {
    return <SatelliteRouteMap points={gpsPoints} height={260} />;
  };

  return (
    <div className="p-4 space-y-4">
      {!isActive ? (
        // Activity Selector
        <Card className="p-4">
          <h3 className="font-bold text-lg mb-4">{t('activeChallenge')}</h3>

          {/* GPS Status */}
          {gpsError && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs font-medium text-yellow-800">GPS Not Available</p>
                <p className="text-xs text-yellow-700">{gpsError}</p>
                <p className="text-xs text-yellow-700 mt-1">No se generarán rutas ni distancias ficticias.</p>
              </div>
            </div>
          )}

          {!gpsError && useRealGPS && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4 flex items-start gap-2">
              <MapPin className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-green-700">GPS real activo. El recorrido se mostrará sobre imágenes satelitales.</p>
            </div>
          )}

          <div className="grid grid-cols-3 gap-2 mb-4">
            {(['walk', 'run', 'cycle', 'swim', 'hike', 'gym', 'football', 'basketball', 'yoga', 'other'] as const).map((type) => (
              <button
                key={type}
                onClick={() => setActivityType(type)}
                className={`p-3 rounded-lg transition-all ${
                  activityType === type
                    ? 'bg-primary text-primary-foreground ring-2 ring-primary'
                    : 'bg-muted hover:bg-muted/70'
                }`}
              >
                <span className="text-2xl block mb-1">{activityIcons[type]}</span>
                <span className="text-xs capitalize font-medium">{type}</span>
              </button>
            ))}
          </div>
          <label className="mb-3 block text-sm">Peso corporal para estimar calorías (kg)<input type="number" min="30" max="250" value={bodyWeight} onChange={(event) => setBodyWeight(event.target.value)} className="mt-1 w-full rounded-md border bg-background p-2" /></label>
          {!gpsRequired && <label className="mb-4 block text-sm">Distancia (km), si corresponde<input type="number" min="0" step="0.01" value={manualDistance} onChange={(event) => setManualDistance(event.target.value)} placeholder="Ej. 1.5" className="mt-1 w-full rounded-md border bg-background p-2" /></label>}
          <Button
            onClick={handleStart}
            className="w-full bg-gradient-to-r from-primary to-secondary text-primary-foreground font-bold py-3"
          >
            <Play className="w-4 h-4 mr-2" />
            {t('startActivity')}
          </Button>
        </Card>
      ) : (
        <>
          {/* Timer */}
          <Card className="bg-gradient-to-br from-primary to-secondary text-primary-foreground p-6 rounded-2xl shadow-lg">
            <div className="text-center mb-4">
              <Clock className="w-6 h-6 mx-auto mb-2 opacity-80" />
              <p className="text-sm opacity-90 mb-2">{t('elapsed')}</p>
              <h2 className="text-5xl font-bold font-mono">{formatTime(stats.time)}</h2>
            </div>
            <div className="text-center">
              <p className="text-sm opacity-90">{t('distance')}</p>
              <p className="text-3xl font-bold">{(gpsRequired ? stats.distance : Number(manualDistance) || 0).toFixed(2)} km</p>
            </div>
          </Card>

          {/* Map */}
          {gpsRequired && <Card className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-lg">{t('route')}</h3>
              {useRealGPS && !gpsError && <Badge className="bg-green-600">GPS satelital</Badge>}
            </div>
            <MapVisualization />
          </Card>}

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3">
            <Card className="p-3">
              <div className="flex items-center gap-2 mb-2">
                <Gauge className="w-4 h-4 text-accent" />
                <p className="text-xs text-muted-foreground">{t('currentSpeed')}</p>
              </div>
              <p className="text-2xl font-bold">{stats.currentSpeed.toFixed(1)} km/h</p>
            </Card>

            <Card className="p-3">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-accent" />
                <p className="text-xs text-muted-foreground">{t('avgSpeed')}</p>
              </div>
              <p className="text-2xl font-bold">{(gpsRequired ? stats.avgSpeed : (Number(manualDistance) || 0) / (stats.time / 3600 || 1)).toFixed(1)} km/h</p>
            </Card>

            <Card className="p-3">
              <p className="text-xs text-muted-foreground mb-1">{t('maxSpeed')}</p>
              <p className="text-2xl font-bold">{(gpsRequired ? stats.maxSpeed : (Number(manualDistance) || 0) / (stats.time / 3600 || 1)).toFixed(1)} km/h</p>
            </Card>

            <Card className="p-3">
              <p className="text-xs text-muted-foreground mb-1">Altitud actual</p>
              <p className="text-2xl font-bold">{stats.elevation > 0 ? `${stats.elevation.toFixed(0)} m` : '—'}</p>
            </Card>
            <Card className="p-3">
              <p className="text-xs text-muted-foreground mb-1">Desnivel positivo</p>
              <p className="text-2xl font-bold">+{stats.elevationGain.toFixed(0)} m</p>
            </Card>

            <Card className="p-3">
              <p className="text-xs text-muted-foreground mb-1">Calorías estimadas</p>
              <p className="text-2xl font-bold">{estimatedCalories} kcal</p>
            </Card>
            <Card className="p-3 col-span-2">
              <p className="text-xs text-muted-foreground mb-1">Recompensas Pi</p>
              <p className="text-sm font-semibold text-muted-foreground">Pendientes de validación del servidor</p>
            </Card>
          </div>

          {/* Controls */}
          <div className="flex gap-3">
            {isPaused ? (
              <Button
                onClick={handleResume}
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                <Play className="w-4 h-4 mr-2" />
                {t('resume')}
              </Button>
            ) : (
              <Button
                onClick={handlePause}
                variant="outline"
                className="flex-1"
              >
                <Pause className="w-4 h-4 mr-2" />
                {t('pause')}
              </Button>
            )}

            <Button
              onClick={handleFinish}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              <Check className="w-4 h-4 mr-2" />
              {t('finishActivity')}
            </Button>
          </div>
        </>
      )}
    </div>
  );
}

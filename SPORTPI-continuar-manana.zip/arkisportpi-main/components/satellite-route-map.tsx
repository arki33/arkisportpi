'use client';

import { useEffect, useRef, useState } from 'react';

type RoutePoint = { lat: number; lng: number };
type LeafletMap = any;

declare global {
  interface Window { L?: any; }
}

let leafletLoader: Promise<any> | null = null;
function loadLeaflet(): Promise<any> {
  if (typeof window === 'undefined') return Promise.reject(new Error('El mapa solo está disponible en el navegador.'));
  if (window.L) return Promise.resolve(window.L);
  if (!leafletLoader) {
    leafletLoader = new Promise((resolve, reject) => {
      if (!document.querySelector('link[data-sportpi-leaflet]')) {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        link.dataset.sportpiLeaflet = 'true';
        document.head.appendChild(link);
      }
      const existing = document.querySelector<HTMLScriptElement>('script[data-sportpi-leaflet]');
      if (existing) {
        existing.addEventListener('load', () => resolve(window.L), { once: true });
        existing.addEventListener('error', () => reject(new Error('No se pudo cargar el motor del mapa.')), { once: true });
        if (window.L) resolve(window.L);
        return;
      }
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.async = true;
      script.dataset.sportpiLeaflet = 'true';
      script.onload = () => window.L ? resolve(window.L) : reject(new Error('Leaflet no está disponible.'));
      script.onerror = () => reject(new Error('No se pudo descargar el motor del mapa.'));
      document.body.appendChild(script);
    });
  }
  return leafletLoader;
}

export default function SatelliteRouteMap({ points, height = 260 }: { points: RoutePoint[]; height?: number }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const layerRef = useRef<any>(null);
  const markerLayerRef = useRef<any>(null);
  const [mapError, setMapError] = useState('');

  useEffect(() => {
    let cancelled = false;
    loadLeaflet().then((L) => {
      if (cancelled || !containerRef.current || mapRef.current) return;
      const fallback: [number, number] = points.length ? [points[points.length - 1].lat, points[points.length - 1].lng] : [0, 0];
      const map = L.map(containerRef.current, { zoomControl: true, attributionControl: true }).setView(fallback, points.length ? 15 : 2);
      if (!points.length && navigator.geolocation) navigator.geolocation.getCurrentPosition((position) => { if (!cancelled) map.setView([position.coords.latitude, position.coords.longitude], 16); }, () => undefined, { enableHighAccuracy: true, timeout: 8000, maximumAge: 60000 });
      // Esri World Imagery satellite tiles. Attribution is displayed on the map.
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 19,
        attribution: 'Tiles © Esri — Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community',
      }).addTo(map);
      mapRef.current = map;
      layerRef.current = L.layerGroup().addTo(map);
      markerLayerRef.current = L.layerGroup().addTo(map);
      window.setTimeout(() => map.invalidateSize(), 100);
    }).catch((error) => {
      if (!cancelled) setMapError(error instanceof Error ? error.message : 'No se pudo cargar el mapa satelital.');
    });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const L = window.L;
    const map = mapRef.current;
    if (!L || !map || !layerRef.current || !markerLayerRef.current) return;
    layerRef.current.clearLayers();
    markerLayerRef.current.clearLayers();
    if (!points.length) return;
    const latLngs = points.map((point) => [point.lat, point.lng] as [number, number]);
    if (latLngs.length > 1) L.polyline(latLngs, { color: '#00e5ff', weight: 5, opacity: 0.9 }).addTo(layerRef.current);
    const start = L.circleMarker(latLngs[0], { radius: 7, color: '#ffffff', weight: 2, fillColor: '#16a34a', fillOpacity: 1 });
    const current = L.circleMarker(latLngs[latLngs.length - 1], { radius: 7, color: '#ffffff', weight: 2, fillColor: '#ef4444', fillOpacity: 1 });
    start.bindTooltip('Inicio'); current.bindTooltip('Posición actual');
    start.addTo(markerLayerRef.current); current.addTo(markerLayerRef.current);
    if (latLngs.length > 1) map.fitBounds(L.latLngBounds(latLngs).pad(0.18), { maxZoom: 17 });
    else map.setView(latLngs[0], 17);
  }, [points]);

  useEffect(() => () => { mapRef.current?.remove(); mapRef.current = null; }, []);

  return (
    <div className="relative w-full overflow-hidden rounded-xl border border-border bg-muted">
      <div ref={containerRef} style={{ height, width: '100%', zIndex: 0 }} aria-label="Mapa satelital del recorrido" />
      <div className="pointer-events-none absolute left-2 top-2 rounded-md bg-black/70 px-2 py-1 text-xs font-semibold text-white">IMAGEN SATELITAL</div>
      {mapError && <div className="absolute inset-x-3 bottom-3 rounded-md bg-black/80 p-2 text-xs text-white">{mapError} Comprueba tu conexión para cargar las imágenes satelitales.</div>}
      <noscript><p className="p-3 text-sm">Activa JavaScript para ver el mapa satelital.</p></noscript>
    </div>
  );
}

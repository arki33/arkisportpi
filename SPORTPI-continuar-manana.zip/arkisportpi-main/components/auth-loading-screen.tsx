"use client";

import { useState } from "react";
import { usePiAuth } from "@/contexts/pi-auth-context";
import { Button } from "@/components/ui/button";
import { AlertCircle, LoaderCircle } from "lucide-react";

export function AuthLoadingScreen() {
  const { status, error, login, reinitialize } = usePiAuth();
  const [loginError, setLoginError] = useState<string | null>(null);
  const busy = status === "loading" || status === "authenticating";

  const handleLogin = async () => {
    setLoginError(null);
    try { await login(); }
    catch (cause) { setLoginError(cause instanceof Error ? cause.message : "No se pudo iniciar sesión con Pi."); }
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-background px-6 py-10">
      <section className="w-full max-w-md rounded-2xl border bg-card p-7 text-center shadow-sm">
        <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground text-3xl font-bold">π</div>
        <h1 className="text-3xl font-bold">SPORTPI</h1>
        <p className="mt-2 text-sm text-muted-foreground">Actividad deportiva dentro del ecosistema Pi Network</p>

        {busy ? (
          <div className="mt-8 flex flex-col items-center gap-3 text-sm text-muted-foreground">
            <LoaderCircle className="h-7 w-7 animate-spin text-primary" />
            {status === "authenticating" ? "Esperando autorización de Pi…" : "Preparando Pi SDK…"}
          </div>
        ) : status === "error" ? (
          <div className="mt-7 space-y-4">
            <div className="flex items-start gap-2 rounded-lg bg-destructive/10 p-3 text-left text-sm text-destructive"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />{error}</div>
            <Button className="w-full" onClick={() => void reinitialize()}>Reintentar carga del SDK</Button>
          </div>
        ) : (
          <div className="mt-8 space-y-3">
            {(loginError || error) && <p role="alert" className="rounded-lg bg-destructive/10 p-3 text-left text-sm text-destructive">{loginError || error}</p>}
            <Button className="w-full" onClick={() => void handleLogin()} disabled={busy}>
              <span className="mr-2 text-lg">π</span> Entrar con Pi Network
            </Button>
            <p className="text-xs text-muted-foreground">Pi Browser es necesario para iniciar sesión fuera del entorno Sandbox. SPORTPI verificará tu identidad con los servidores oficiales de Pi.</p>
          </div>
        )}
      </section>
    </main>
  );
}

/** @type {import('next').NextConfig} */
const nextConfig = {
  // Keep TypeScript and lint failures visible during production builds.
  images: { unoptimized: true },
};

export default nextConfig;

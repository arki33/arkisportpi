# SPORTPI — punto de continuación

Este archivo resume el estado del proyecto para retomar el trabajo sin perder los acuerdos.

## Base del proyecto

- Proyecto: Next.js 15.5.12 + React 19 + TypeScript.
- Entorno previsto: Ubuntu 24.04 en WSL2.
- Node.js 26.13.1, npm 11.20.0 y Git 2.43.0 comprobados dentro de Ubuntu.
- Docker 29.9.3 comprobado en Windows.
- VS Code no se ha localizado en las rutas habituales de Windows y el comando `code` no está disponible.
- Base de datos prevista: PostgreSQL externo (por ejemplo Supabase o Neon). Pi Network no proporciona una base de datos PostgreSQL general para esta app.

## Funciones incorporadas en el código

- SDK de Pi 2.0, inicialización y autenticación; verificación del token en el servidor con Pi Platform API.
- Mapa de ruta con imágenes satelitales Esri World Imagery y atribución del proveedor.
- Geolocalización real para caminar, correr, bicicleta y senderismo; filtrado básico de precisión y saltos improbables.
- Cronómetro con iniciar, pausar, reanudar y finalizar.
- Deportes: caminar, correr, bicicleta, natación, senderismo, gimnasio, fútbol, baloncesto, yoga y otros.
- Distancia, velocidad, altitud/desnivel si el dispositivo los proporciona y calorías estimadas.
- Natación y deportes de interior con distancia manual opcional.
- Contador de pasos aproximado con sensor de movimiento, sujeto a compatibilidad y permisos del navegador.
- Historial local y sincronización con API/PostgreSQL cuando se configure el servidor.
- API de actividades, desafíos públicos y clasificación.
- Esquema Prisma para usuarios Pi, actividades, desafíos, participantes, pagos y ledger de recompensas.

## Límites que no deben confundirse con funciones terminadas

- La base de datos no está creada ni conectada: falta configurar `DATABASE_URL`.
- Falta configurar `PI_API_KEY` desde Pi Developer Portal. Es un secreto de servidor; no usar prefijo `NEXT_PUBLIC_`.
- La clasificación solo cuenta actividades con `verified=true`; todavía no hay un proceso de revisión/antifraude que valide actividades.
- El progreso de desafíos (distancia, duración, pasos y sesiones) todavía requiere cálculo/actualización fiable en servidor.
- Las recompensas Pi no se calculan ni se acreditan desde el cliente. Falta completar reglas, ledger, controles antifraude y proceso de pagos.
- El GPS y el sensor de pasos pueden dejar de funcionar al bloquear el teléfono o mandar el navegador a segundo plano.
- El GPS no funciona bajo el agua; natación debe registrar distancia manualmente o mediante integración compatible.
- Las calorías son estimaciones, no mediciones clínicas.
- El mapa satelital necesita conexión a Internet para descargar las teselas; los datos móviles del teléfono sirven como conexión de red si Pi Browser tiene permiso para usarlos.

## Pasos para retomar en Ubuntu 24.04 (WSL)

Desde PowerShell, entrar en Ubuntu:

```powershell
wsl -d Ubuntu-24.04
```

Después, en la terminal de Ubuntu, entrar en la carpeta donde se descomprima el proyecto y ejecutar:

```bash
npm install
npx prisma generate
```

Crear `.env.local` a partir de `.env.example` y configurar los valores reales:

- `PI_API_KEY`: clave privada de servidor de la app Pi.
- `DATABASE_URL`: cadena de conexión PostgreSQL real, con SSL según proveedor.
- `NEXT_PUBLIC_PI_SANDBOX=true` durante pruebas en Sandbox/Testnet.

Cuando la base de datos esté disponible:

```bash
npx prisma db push
npm run typecheck
npm run build
npm run dev
```

No inventar valores de claves ni de conexión. No subir `.env.local` ni compartir secretos.

## Estado de verificación de este paquete

- ZIP extraído correctamente y estructura del proyecto revisada.
- Se revisaron las rutas API principales, el esquema Prisma, autenticación Pi, rastreador GPS, mapa satelital, contador de pasos e historial.
- Se actualizó esta guía para usar npm, disponible en Ubuntu, en lugar de asumir que pnpm está instalado.
- No se pudo completar `npm install` durante la preparación por límite de tiempo del entorno; por tanto no se afirma que `typecheck` o `next build` hayan pasado.
- Este paquete es una versión de desarrollo para continuar, no una versión lista para Mainnet/producción.

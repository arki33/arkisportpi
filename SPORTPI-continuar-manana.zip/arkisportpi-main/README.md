# SPORTPI

SPORTPI is a Next.js Pi App frontend with a server-side Pi Platform API integration.

## Current architecture

- Pi SDK 2.0 is loaded once from `https://sdk.minepi.com/pi-sdk.js` and initialized centrally.
- Sign-in uses `Pi.authenticate()` and the access token is verified by the server against Pi Platform API `GET /me`.
- User profiles, activity history, payment orders and product entitlements are stored in PostgreSQL through Prisma.
- Pi User-to-App payments use server-side approval and completion. The Server API Key is read only on the server.
- Walk/run/cycle/hike GPS points are collected from device geolocation and displayed on Esri World Imagery satellite tiles through Leaflet. GPS is not a guaranteed background tracker; keep SPORTPI open and grant location permission.
- The activity timer supports walking, running, cycling, swimming, hiking, gym, football, basketball, yoga and other sports. Swimming and indoor sessions use manual distance where applicable.
- The phone motion sensor can estimate steps while the dashboard is open and the user has granted motion permission; browser-based steps are approximate and are not a certified all-day pedometer.
- Calories are estimates based on MET values and the body weight entered for the session; they are not medical measurements.
- Activities are marked unverified. They are not eligible for Pi rewards until a real anti-cheat/review process is implemented.

## Requirements

- Node.js 20.9 or newer (Node.js 22 recommended)
- pnpm
- PostgreSQL database
- Pi Developer Portal app configured for Testnet/Sandbox during development

## Configure local development

1. Copy `.env.example` to `.env.local`.
2. Set `PI_API_KEY` to the Server API Key from the Pi Developer Portal. Keep it private and never expose it to the browser.
3. Set `DATABASE_URL` to a PostgreSQL database you control.
4. Keep `NEXT_PUBLIC_PI_SANDBOX=true` while testing in Pi Sandbox.
5. Install dependencies and generate Prisma Client:

   ```bash
   pnpm install
   pnpm db:generate
   pnpm db:push
   ```

6. Start Next.js:

   ```bash
   pnpm dev
   ```

7. Configure the Development URL in the Pi Developer Portal and open the generated Sandbox URL. The Pi Sandbox must be authorized from Pi Utilities.

## Product catalogue and purchases

The product catalogue is intentionally empty until SPORTPI's actual products, prices and benefits are agreed. No real purchase button is enabled while the catalogue is empty. Add products in `lib/pi-products.ts`. Each product must have a unique `id`, public name/description, Pi `amount`, and server-side `entitlement` key. The server uses this catalogue as the source of truth; do not accept a price from the browser.

The payment routes create an order, validate the Pi payment's user, direction, amount and metadata, approve it, complete it, and record the entitlement in PostgreSQL. Do not enable payments until a real product catalogue and app wallet configuration have been reviewed and tested in Sandbox.

## Current feature boundaries

- Pi sign-in and server-side identity verification are wired to the official Pi Platform API.
- GPS activity capture and user-scoped activity persistence are implemented.
- Pi-authenticated users can create and join public challenges. The leaderboard reads only activities marked verified by the server. Activity verification, challenge progress aggregation, friend-only challenges and reward qualification/review/payout still need a complete anti-cheat and moderation workflow.
- The reward ledger table is a data-model foundation only; it does not issue Pi or credit rewards.

## Satellite map and device sensors

- The route map uses Esri World Imagery satellite tiles. The map engine is loaded from Leaflet 1.9.4 via unpkg and requires internet access. Esri tile availability, terms and attribution apply.
- Browser geolocation and motion sensors require a secure HTTPS origin and explicit device permissions. iOS and Android browsers may suspend sensor/GPS updates when the app is backgrounded or the screen is locked.
- Altitude is only as accurate as the device location provider; many phones return null or noisy altitude values. Swimming GPS is not supported underwater, so pool distance must be entered manually.

## Rewards and payouts

SPORTPI does not award Pi from browser-calculated distance or client-supplied values. Activity data is saved as unverified. A server-side anti-cheat process and a reward approval ledger must be implemented before any Pi reward can be granted.

Pi App-to-User payouts require separate wallet setup and signing controls. Pi's current Advanced Payments documentation says A2U is available on Testnet; Mainnet availability is restricted to selected apps and requires the relevant outgoing-wallet approval. Do not store wallet secret seeds in this repository or in client environment variables.

## Production checklist

- Set `NEXT_PUBLIC_PI_SANDBOX=false` only for the Mainnet deployment.
- Use a different registered Pi Developer Portal app for Testnet and Mainnet.
- Deploy the Next.js app and API routes to a Node.js host with HTTPS and persistent PostgreSQL.
- Set `PI_API_KEY` and `DATABASE_URL` in the hosting provider's server-side environment settings.
- Run `pnpm db:generate` and `pnpm db:push` as part of deployment/release operations.
- Complete the full Pi Sandbox authentication and User-to-App payment tests before applying for Mainnet review.

## Important

A ZIP file is the source project. Pi Developer Portal normally routes to a deployed HTTPS URL or a configured Sandbox development URL; it is not a substitute for hosting the Next.js frontend and API backend. See the Pi Developer documentation for current URL and deployment requirements.

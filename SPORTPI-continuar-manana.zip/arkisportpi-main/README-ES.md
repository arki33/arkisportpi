# SPORTPI — versión de trabajo con seguimiento deportivo

Esta carpeta contiene el código fuente de SPORTPI. No es todavía un despliegue listo para producción ni una aplicación que se pueda publicar directamente en Pi Developer Portal.

## Funciones incluidas en esta versión

- Autenticación de usuario mediante Pi SDK y verificación del token en el servidor.
- Cronómetro con iniciar, pausar, reanudar y finalizar.
- Deportes: caminar, correr, bicicleta, natación, senderismo, gimnasio, fútbol, baloncesto, yoga y otros.
- GPS real para caminar, correr, bicicleta y senderismo. Se filtran posiciones con precisión deficiente y no se inventan coordenadas.
- Mapa de ruta con imágenes satelitales Esri World Imagery y atribución visible. Leaflet 1.9.4 se carga desde un CDN; requiere conexión a Internet.
- Natación y deportes de interior: cronómetro y distancia manual opcional. El GPS no sirve para seguir una ruta bajo el agua.
- Velocidad, distancia, altitud/desnivel cuando el dispositivo los proporciona y calorías estimadas según MET y el peso indicado para la sesión.
- Historial local y sincronización de actividades con PostgreSQL cuando la sesión Pi y el servidor están configurados.
- Contador aproximado de pasos mediante el sensor de movimiento del teléfono, con permiso explícito. Solo cuenta mientras la página puede recibir eventos; no sustituye a un podómetro del sistema o reloj.
- Creación y unión a desafíos públicos entre cuentas Pi autenticadas.
- Clasificación basada exclusivamente en actividades que el servidor haya marcado como verificadas. En esta versión no hay todavía un proceso de revisión/validación que marque actividades como verificadas, por lo que puede aparecer vacía.

## Requisitos y configuración

1. Node.js 20.9 o superior.
2. PostgreSQL (por ejemplo, Supabase o Neon; Pi Network no proporciona una base PostgreSQL general para esta aplicación).
3. Copiar `.env.example` como `.env.local` y configurar `PI_API_KEY`, `DATABASE_URL` y `NEXT_PUBLIC_PI_SANDBOX`.
4. Instalar dependencias y preparar Prisma:

   ```bash
   npm install
   npx prisma generate
   npx prisma db push
   npm run dev
   ```

5. Abre `http://localhost:3000` para desarrollo local. Para probar autenticación Pi y permisos GPS en el teléfono, utiliza Pi Browser/Sandbox y la URL de desarrollo admitida por el entorno de pruebas. La API de Pi necesita la clave privada del servidor; nunca la pongas en variables `NEXT_PUBLIC_`.

## Limitaciones que deben resolverse antes de Mainnet

- El GPS y el sensor de pasos pueden suspenderse cuando el navegador queda en segundo plano o se bloquea el teléfono. Para seguimiento fiable en segundo plano se necesitaría una aplicación nativa o integración compatible con el sistema de salud/reloj.
- La altitud del GPS puede faltar o ser imprecisa. Las calorías son aproximaciones, no mediciones clínicas.
- El progreso de desafíos y las clasificaciones con premios deben alimentarse solo con actividades validadas. Hace falta completar antifraude, revisión, moderación, límites de frecuencia y pruebas de seguridad.
- No se emiten ni se abonan Pi desde el navegador. El ledger y los pagos requieren un proceso de servidor, presupuesto real y pruebas en Pi Sandbox.
- Deben probarse todos los flujos en dispositivos Android/iOS reales y ejecutar `pnpm build` después de instalar dependencias y configurar la base de datos.


## Comprobación del entorno

El proyecto requiere Node.js 20.9 o superior. En el entorno de trabajo actual ya se comprobó Node.js 26.13.1, npm 11.20.0 y Git 2.43.0 dentro de Ubuntu 24.04 en WSL2. Docker 29.9.3 está instalado en Windows. VS Code todavía no se ha localizado/confirmado en Windows.

Para revisar el código y compilar cuando las dependencias estén instaladas:

```bash
npm run typecheck
npm run build
```

La compilación de producción aún no está certificada. La instalación de dependencias no se pudo completar durante la preparación de este paquete por un límite de tiempo del entorno de trabajo.

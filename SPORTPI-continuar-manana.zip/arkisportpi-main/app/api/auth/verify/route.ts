import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readBearerToken, verifyPiAccessToken } from "@/lib/pi-platform";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: "Falta el token de autenticación de Pi." }, { status: 401 });
  try {
    const piUser = await verifyPiAccessToken(token);
    if (!piUser.uid) return NextResponse.json({ error: "Pi no devolvió un identificador de usuario válido." }, { status: 401 });
    const user = await db.piUser.upsert({
      where: { uid: piUser.uid },
      create: { uid: piUser.uid, username: piUser.username ?? null, walletAddress: piUser.wallet_address ?? null },
      update: { username: piUser.username ?? null, walletAddress: piUser.wallet_address ?? null },
      select: { uid: true, username: true, walletAddress: true, createdAt: true },
    });
    return NextResponse.json({ user: { uid: user.uid, username: user.username, wallet_address: user.walletAddress, createdAt: user.createdAt } });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo verificar la identidad con Pi." }, { status: 401 });
  }
}

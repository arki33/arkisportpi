import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readBearerToken, verifyPiAccessToken } from "@/lib/pi-platform";
import { getPiProduct } from "@/lib/pi-products";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  try {
    const user = await verifyPiAccessToken(token);
    const body = await request.json();
    const product = typeof body.productId === "string" ? getPiProduct(body.productId) : undefined;
    if (!product) return NextResponse.json({ error: "Producto no disponible. Configura primero el catálogo de SPORTPI en lib/pi-products.ts." }, { status: 404 });
    await db.piUser.upsert({ where: { uid: user.uid }, create: { uid: user.uid, username: user.username ?? null, walletAddress: user.wallet_address ?? null }, update: { username: user.username ?? null, walletAddress: user.wallet_address ?? null } });
    const order = await db.piPayment.create({
      data: { userUid: user.uid, productId: product.id, amount: product.amount, memo: `SPORTPI: ${product.name}`, status: "prepared" },
      select: { id: true },
    });
    return NextResponse.json({ orderId: order.id, product: { id: product.id, name: product.name, amount: product.amount, description: product.description } });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo preparar el pago." }, { status: 400 });
  }
}

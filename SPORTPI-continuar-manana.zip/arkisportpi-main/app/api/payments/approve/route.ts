import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { approvePiPayment, getPiPayment, readBearerToken, verifyPiAccessToken } from "@/lib/pi-platform";
import { getPiProduct } from "@/lib/pi-products";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  try {
    const user = await verifyPiAccessToken(token);
    const { paymentId } = await request.json();
    if (typeof paymentId !== "string" || !paymentId) return NextResponse.json({ error: "paymentId no válido." }, { status: 400 });
    const payment = await getPiPayment(paymentId);
    const orderId = typeof payment.metadata?.sportpiOrderId === "string" ? payment.metadata.sportpiOrderId : "";
    const order = orderId ? await db.piPayment.findUnique({ where: { id: orderId } }) : null;
    const product = order ? getPiProduct(order.productId) : undefined;
    if (!order || !product || order.userUid !== user.uid || payment.user_uid !== user.uid || payment.direction !== "user_to_app") return NextResponse.json({ error: "No se pudo validar el pedido o la identidad del pagador." }, { status: 403 });
    if (Number(order.amount) !== payment.amount || payment.amount !== product.amount || payment.memo !== order.memo || payment.metadata?.sportpiProductId !== product.id) return NextResponse.json({ error: "Los datos del pago no coinciden con el pedido oficial." }, { status: 400 });
    if (payment.status.cancelled || payment.status.user_cancelled) return NextResponse.json({ error: "El pago está cancelado." }, { status: 409 });
    await db.piPayment.update({ where: { id: order.id }, data: { piPaymentId: paymentId, status: "approval_pending" } });
    if (!payment.status.developer_approved) await approvePiPayment(paymentId);
    await db.piPayment.update({ where: { id: order.id }, data: { status: "approved" } });
    return NextResponse.json({ approved: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo aprobar el pago." }, { status: 400 });
  }
}

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { completePiPayment, getPiPayment, readBearerToken, verifyPiAccessToken } from "@/lib/pi-platform";
import { getPiProduct } from "@/lib/pi-products";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  try {
    const user = await verifyPiAccessToken(token);
    const { paymentId, txid } = await request.json();
    if (typeof paymentId !== "string" || typeof txid !== "string") return NextResponse.json({ error: "Datos del pago incompletos." }, { status: 400 });
    const payment = await getPiPayment(paymentId);
    if (payment.user_uid !== user.uid || payment.direction !== "user_to_app") return NextResponse.json({ error: "El pago no pertenece a este usuario." }, { status: 403 });
    const orderId = typeof payment.metadata?.sportpiOrderId === "string" ? payment.metadata.sportpiOrderId : "";
    const order = orderId ? await db.piPayment.findUnique({ where: { id: orderId } }) : null;
    const product = order ? getPiProduct(order.productId) : undefined;
    if (!order || !product || order.userUid !== user.uid || payment.amount !== product.amount || payment.memo !== order.memo || payment.metadata?.sportpiProductId !== product.id) return NextResponse.json({ error: "No se puede validar el pedido pendiente." }, { status: 403 });
    if (!payment.status.developer_approved || payment.status.cancelled || payment.status.user_cancelled) return NextResponse.json({ error: "El pago no está aprobado o está cancelado." }, { status: 409 });
    if (!payment.transaction?.verified || payment.transaction.txid !== txid) return NextResponse.json({ error: "La transacción no está verificada." }, { status: 409 });
    if (payment.status.developer_completed) {
      await db.$transaction([
        db.piPayment.update({ where: { id: order.id }, data: { status: "completed", txid, completedAt: new Date() } }),
        db.entitlement.upsert({ where: { paymentId: order.id }, create: { userUid: user.uid, productId: product.id, paymentId: order.id }, update: { active: true } }),
      ]);
      return NextResponse.json({ completed: true, alreadyCompleted: true });
    }
    await completePiPayment(paymentId, txid);
    await db.$transaction([
      db.piPayment.update({ where: { id: order.id }, data: { piPaymentId: paymentId, status: "completed", txid, completedAt: new Date() } }),
      db.entitlement.upsert({ where: { paymentId: order.id }, create: { userUid: user.uid, productId: product.id, paymentId: order.id }, update: { active: true } }),
    ]);
    return NextResponse.json({ completed: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo recuperar el pago." }, { status: 400 });
  }
}

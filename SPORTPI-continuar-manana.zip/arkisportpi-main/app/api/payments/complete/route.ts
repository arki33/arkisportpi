import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { completePiPayment, getPiPayment, readBearerToken, verifyPiAccessToken } from "@/lib/pi-platform";
import { getPiProduct } from "@/lib/pi-products";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  try {
    const user = await verifyPiAccessToken(token);
    const { paymentId, txid } = await request.json();
    if (typeof paymentId !== "string" || !paymentId || typeof txid !== "string" || !txid) return NextResponse.json({ error: "paymentId o txid no válido." }, { status: 400 });
    const payment = await getPiPayment(paymentId);
    const orderId = typeof payment.metadata?.sportpiOrderId === "string" ? payment.metadata.sportpiOrderId : "";
    const order = orderId ? await db.piPayment.findUnique({ where: { id: orderId } }) : null;
    const product = order ? getPiProduct(order.productId) : undefined;
    if (!order || !product || order.userUid !== user.uid || payment.user_uid !== user.uid || payment.direction !== "user_to_app") return NextResponse.json({ error: "El pago no pertenece al usuario o pedido esperado." }, { status: 403 });
    if (payment.amount !== product.amount || Number(order.amount) !== payment.amount || payment.memo !== order.memo || payment.metadata?.sportpiProductId !== product.id) return NextResponse.json({ error: "El importe o producto del pago no coincide." }, { status: 400 });
    if (!payment.status.developer_approved || payment.status.cancelled || payment.status.user_cancelled) return NextResponse.json({ error: "El pago no está aprobado o está cancelado." }, { status: 409 });
    if (!payment.transaction?.verified || payment.transaction.txid !== txid) return NextResponse.json({ error: "La transacción todavía no está verificada por Pi." }, { status: 409 });
    if (payment.status.developer_completed) {
      await db.$transaction([
        db.piPayment.update({ where: { id: order.id }, data: { status: "completed", txid, completedAt: new Date() } }),
        db.entitlement.upsert({
          where: { paymentId: order.id },
          create: { userUid: user.uid, productId: product.id, paymentId: order.id },
          update: { active: true },
        }),
      ]);
    } else {
      await completePiPayment(paymentId, txid);
      await db.$transaction([
        db.piPayment.update({ where: { id: order.id }, data: { status: "completed", txid, completedAt: new Date() } }),
        db.entitlement.upsert({
          where: { paymentId: order.id },
          create: { userUid: user.uid, productId: product.id, paymentId: order.id },
          update: { active: true },
        }),
      ]);
    }
    return NextResponse.json({ completed: true, productId: product.id, entitlement: product.entitlement });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo completar el pago." }, { status: 400 });
  }
}

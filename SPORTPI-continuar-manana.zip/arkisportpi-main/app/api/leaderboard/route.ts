import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { readBearerToken, verifyPiAccessToken } from '@/lib/pi-platform';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: 'Inicia sesión con Pi para consultar la clasificación.' }, { status: 401 });
  try {
    await verifyPiAccessToken(token);
    const totals = await db.activity.groupBy({
      by: ['userUid'], where: { verified: true },
      _sum: { distanceKm: true, durationSec: true }, _count: { _all: true },
      orderBy: { _sum: { distanceKm: 'desc' } }, take: 100,
    });
    const users = await db.piUser.findMany({ where: { uid: { in: totals.map((row) => row.userUid) } }, select: { uid: true, username: true } });
    const usernames = new Map(users.map((user) => [user.uid, user.username || 'Usuario Pi']));
    return NextResponse.json({ leaderboard: totals.map((row) => ({
      username: usernames.get(row.userUid) || 'Usuario Pi',
      distanceKm: Number(row._sum.distanceKm || 0),
      durationSec: row._sum.durationSec || 0,
      activities: row._count._all,
    })) });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'No se pudo consultar la clasificación.' }, { status: 400 });
  }
}

import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

export async function GET() {
  const checks = {
    database: false,
    piServerApiKey: Boolean(process.env.PI_API_KEY),
    piSandbox: process.env.NEXT_PUBLIC_PI_SANDBOX !== "false",
  };
  try {
    await db.$queryRaw`SELECT 1`;
    checks.database = true;
  } catch {
    checks.database = false;
  }
  const ready = checks.database && checks.piServerApiKey;
  return NextResponse.json({ status: ready ? "ready" : "configuration_required", checks }, { status: ready ? 200 : 503 });
}

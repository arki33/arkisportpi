import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readBearerToken, verifyPiAccessToken } from "@/lib/pi-platform";

export const runtime = "nodejs";
const validTypes = new Set(["walk", "run", "cycle", "swim", "hike", "gym", "football", "basketball", "yoga", "other"]);

type Point = { lat: number; lng: number; timestamp: number };
function distanceKm(a: Point, b: Point) {
  const rad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * rad;
  const dLng = (b.lng - a.lng) * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

export async function GET(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  try {
    const user = await verifyPiAccessToken(token);
    const activities = await db.activity.findMany({ where: { userUid: user.uid }, orderBy: { createdAt: "desc" }, take: 100 });
    return NextResponse.json({ activities: activities.map((item) => ({
      id: item.id, type: item.type, distance: Number(item.distanceKm), duration: item.durationSec, caloriesKcal: item.caloriesKcal,
      avgSpeed: Number(item.avgSpeedKmh), maxSpeed: Number(item.maxSpeedKmh), elevationGain: Number(item.elevationM),
      piEarned: 0, startTime: item.startedAt, endTime: item.endedAt, gpsRoute: item.gpsRoute,
      verified: item.verified,
    })) });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudieron cargar las actividades." }, { status: 400 });
  }
}

export async function POST(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  try {
    const user = await verifyPiAccessToken(token);
    const body = await request.json();
    if (typeof body.id !== "string" || !body.id || !validTypes.has(body.type) || !Array.isArray(body.gpsRoute) || body.gpsRoute.length > 500) {
      return NextResponse.json({ error: "Datos de actividad incompletos o no válidos." }, { status: 400 });
    }
    const route: Point[] = body.gpsRoute.map((point: Record<string, unknown>) => ({ lat: Number(point.lat), lng: Number(point.lng), timestamp: Number(point.timestamp) }));
    const requiresGps = new Set(["walk", "run", "cycle", "hike"]).has(body.type);
    if (requiresGps && route.length < 2) return NextResponse.json({ error: "Esta actividad necesita al menos dos puntos GPS válidos." }, { status: 400 });
    if (route.some((point) => !Number.isFinite(point.lat) || !Number.isFinite(point.lng) || !Number.isFinite(point.timestamp) || Math.abs(point.lat) > 90 || Math.abs(point.lng) > 180)) {
      return NextResponse.json({ error: "La ruta contiene coordenadas no válidas." }, { status: 400 });
    }
    const durationSec = Math.floor(Number(body.duration));
    const startedAt = new Date(body.startTime);
    const endedAt = new Date(body.endTime);
    if (!Number.isFinite(durationSec) || durationSec < 10 || durationSec > 86400 || !Number.isFinite(startedAt.getTime()) || !Number.isFinite(endedAt.getTime()) || endedAt <= startedAt) return NextResponse.json({ error: "Duración o fechas de actividad no válidas." }, { status: 400 });
    let distance = route.length >= 2 ? 0 : Math.max(0, Number(body.distance) || 0);
    let maxSpeed = 0;
    for (let i = 1; i < route.length; i++) {
      const segment = distanceKm(route[i - 1], route[i]);
      const seconds = Math.max((route[i].timestamp - route[i - 1].timestamp) / 1000, 0.1);
      const speed = segment / (seconds / 3600);
      if (speed > 120) return NextResponse.json({ error: "La ruta contiene un desplazamiento físicamente inverosímil." }, { status: 422 });
      distance += segment;
      maxSpeed = Math.max(maxSpeed, speed);
    }
    if (route.length < 2 && distance > 0) maxSpeed = distance / (durationSec / 3600);
    const averageSpeed = distance / (durationSec / 3600);
    if (averageSpeed > 80) return NextResponse.json({ error: "La velocidad media no supera las comprobaciones básicas de plausibilidad." }, { status: 422 });
    const existing = await db.activity.findUnique({ where: { id: body.id }, select: { userUid: true } });
    if (existing && existing.userUid !== user.uid) return NextResponse.json({ error: "El identificador de actividad ya está en uso." }, { status: 409 });
    const activity = await db.activity.upsert({
      where: { id: body.id },
      create: {
        id: body.id, userUid: user.uid, type: body.type, distanceKm: distance,
        durationSec, avgSpeedKmh: averageSpeed, maxSpeedKmh: maxSpeed,
        elevationM: Math.max(0, Number(body.elevationGain) || 0), caloriesKcal: Math.max(0, Math.min(5000, Math.floor(Number(body.caloriesKcal) || 0))),
        startedAt, endedAt, gpsRoute: route,
        verified: false,
      },
      update: {},
    });
    return NextResponse.json({ saved: true, verified: activity.verified, distanceKm: Number(activity.distanceKm), rewardStatus: "not_eligible_until_server_review" }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo guardar la actividad." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  try {
    const user = await verifyPiAccessToken(token);
    const body = await request.json();
    if (typeof body.id !== "string" || !body.id) return NextResponse.json({ error: "Falta el identificador de la actividad." }, { status: 400 });
    await db.activity.deleteMany({ where: { id: body.id, userUid: user.uid } });
    return NextResponse.json({ deleted: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo eliminar la actividad." }, { status: 400 });
  }
}

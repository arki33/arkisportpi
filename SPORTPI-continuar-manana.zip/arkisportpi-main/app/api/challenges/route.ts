import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { readBearerToken, verifyPiAccessToken } from '@/lib/pi-platform';

export const runtime = 'nodejs';
const types = new Set(['any', 'walk', 'run', 'cycle', 'swim', 'hike', 'gym', 'football', 'basketball', 'yoga', 'other']);
const metrics = new Set(['distance', 'duration', 'steps', 'sessions']);

export async function GET(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: 'Inicia sesión con Pi para ver los desafíos.' }, { status: 401 });
  try {
    const piUser = await verifyPiAccessToken(token);
    const now = new Date();
    const challenges = await db.challenge.findMany({
      where: { visibility: 'public', status: 'open', endsAt: { gte: now } },
      include: {
        creator: { select: { username: true } },
        participants: { where: { userUid: piUser.uid }, select: { userUid: true } },
        _count: { select: { participants: true } },
      },
      orderBy: { startsAt: 'asc' }, take: 50,
    });
    return NextResponse.json({ challenges: challenges.map((item) => ({
      id: item.id, title: item.title, description: item.description, activityType: item.activityType,
      metric: item.metric, targetValue: Number(item.targetValue), startsAt: item.startsAt,
      endsAt: item.endsAt, creator: item.creator.username || 'Usuario Pi',
      participantCount: item._count.participants,
      joined: item.participants.some((participant) => participant.userUid === piUser.uid),
      
    })) });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'No se pudieron cargar los desafíos.' }, { status: 400 });
  }
}

export async function POST(request: Request) {
  const token = readBearerToken(request);
  if (!token) return NextResponse.json({ error: 'Inicia sesión con Pi.' }, { status: 401 });
  try {
    const piUser = await verifyPiAccessToken(token);
    const body = await request.json();
    if (body.action === 'join') {
      if (typeof body.challengeId !== 'string') return NextResponse.json({ error: 'Falta el identificador del desafío.' }, { status: 400 });
      const challenge = await db.challenge.findFirst({ where: { id: body.challengeId, status: 'open', visibility: 'public', endsAt: { gte: new Date() } } });
      if (!challenge) return NextResponse.json({ error: 'El desafío no existe o ya ha finalizado.' }, { status: 404 });
      await db.challengeParticipant.upsert({ where: { challengeId_userUid: { challengeId: challenge.id, userUid: piUser.uid } }, create: { challengeId: challenge.id, userUid: piUser.uid }, update: {} });
      return NextResponse.json({ joined: true });
    }
    if (body.action === 'create') {
      const title = typeof body.title === 'string' ? body.title.trim().slice(0, 80) : '';
      const description = typeof body.description === 'string' ? body.description.trim().slice(0, 500) : null;
      const activityType = String(body.activityType || 'any');
      const metric = String(body.metric || 'distance');
      const targetValue = Number(body.targetValue);
      const startsAt = new Date(body.startsAt);
      const endsAt = new Date(body.endsAt);
      if (!title || !types.has(activityType) || !metrics.has(metric) || !Number.isFinite(targetValue) || targetValue <= 0 || !Number.isFinite(startsAt.getTime()) || !Number.isFinite(endsAt.getTime()) || endsAt <= startsAt || endsAt.getTime() < Date.now() || endsAt.getTime() - startsAt.getTime() > 90 * 86400000) {
        return NextResponse.json({ error: 'Datos de desafío no válidos.' }, { status: 400 });
      }
      const challenge = await db.challenge.create({ data: { creatorUid: piUser.uid, title, description, activityType, metric, targetValue, startsAt, endsAt, visibility: 'public' } });
      await db.challengeParticipant.create({ data: { challengeId: challenge.id, userUid: piUser.uid } });
      return NextResponse.json({ created: true, challengeId: challenge.id }, { status: 201 });
    }
    return NextResponse.json({ error: 'Acción no reconocida.' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'No se pudo procesar el desafío.' }, { status: 400 });
  }
}

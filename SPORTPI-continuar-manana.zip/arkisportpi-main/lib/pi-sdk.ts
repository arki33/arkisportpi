export type PiUser = {
  uid: string;
  username?: string;
  wallet_address?: string;
};

export type PiPaymentDTO = {
  identifier: string;
  user_uid: string;
  amount: number;
  memo: string;
  metadata: Record<string, unknown>;
  direction: "user_to_app" | "app_to_user";
  status: {
    developer_approved: boolean;
    transaction_verified: boolean;
    developer_completed: boolean;
    cancelled: boolean;
    user_cancelled: boolean;
  };
  transaction: null | { txid: string; verified: boolean };
};

export type PiAuthResult = { accessToken: string; user: PiUser };
export type PiPaymentCallbacks = {
  onReadyForServerApproval: (paymentId: string) => void | Promise<void>;
  onReadyForServerCompletion: (paymentId: string, txid: string) => void | Promise<void>;
  onCancel: (paymentId: string) => void;
  onError: (error: Error, payment?: PiPaymentDTO) => void;
};

export type PiSdk = {
  init: (config: { version: "2.0"; sandbox?: boolean }) => void | Promise<void>;
  authenticate: (
    scopes: Array<"username" | "payments" | "wallet_address" | "in_app_notifications">,
    onIncompletePaymentFound: (payment: PiPaymentDTO) => void | Promise<void>
  ) => Promise<PiAuthResult>;
  createPayment: (
    data: { amount: number; memo: string; metadata: Record<string, unknown> },
    callbacks: PiPaymentCallbacks
  ) => void;
};

declare global {
  interface Window {
    Pi?: PiSdk;
  }
}

let sdkPromise: Promise<PiSdk> | null = null;
let initPromise: Promise<void> | null = null;

export function loadPiSdk(): Promise<PiSdk> {
  if (typeof window === "undefined") return Promise.reject(new Error("Pi SDK solo está disponible en el navegador."));
  if (window.Pi) return Promise.resolve(window.Pi);
  if (sdkPromise) return sdkPromise;

  sdkPromise = new Promise<PiSdk>((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>('script[data-pi-sdk="true"]');
    const script = existing ?? document.createElement("script");
    const onLoad = () => window.Pi ? resolve(window.Pi) : reject(new Error("El SDK de Pi se cargó, pero window.Pi no está disponible."));
    const onError = () => reject(new Error("No se pudo cargar el SDK oficial de Pi Network."));
    script.addEventListener("load", onLoad, { once: true });
    script.addEventListener("error", onError, { once: true });
    if (!existing) {
      script.src = "https://sdk.minepi.com/pi-sdk.js";
      script.async = true;
      script.dataset.piSdk = "true";
      document.head.appendChild(script);
    }
    if (window.Pi) resolve(window.Pi);
  }).catch((error) => {
    sdkPromise = null;
    throw error;
  });
  return sdkPromise;
}

export async function initializePiSdk(): Promise<PiSdk> {
  const sdk = await loadPiSdk();
  if (!initPromise) {
    const sandbox = process.env.NEXT_PUBLIC_PI_SANDBOX !== "false";
    initPromise = Promise.resolve()
      .then(() => sdk.init({ version: "2.0", sandbox }))
      .then(() => undefined)
      .catch((error) => {
        initPromise = null;
        throw error;
      });
  }
  await initPromise;
  return sdk;
}

/**
 * Server-authoritative Pi product catalogue.
 * Add real products and prices here only after deciding the SPORTPI offer/pricing.
 * The client must never choose or override the amount charged by Pi.
 */
export type PiProduct = { id: string; name: string; description: string; amount: number; entitlement: string };

export const PI_PRODUCTS: PiProduct[] = [];

export function getPiProduct(id: string): PiProduct | undefined {
  return PI_PRODUCTS.find((product) => product.id === id);
}

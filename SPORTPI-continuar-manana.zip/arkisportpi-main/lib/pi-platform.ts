import "server-only";

const PI_API_BASE = "https://api.minepi.com/v2";

function getApiKey(): string {
  const key = process.env.PI_API_KEY;
  if (!key) throw new Error("Falta PI_API_KEY en las variables de entorno del servidor.");
  return key;
}

async function piFetch<T>(path: string, options: RequestInit = {}, auth: "key" | "bearer" = "key", token?: string): Promise<T> {
  const credential = auth === "key" ? getApiKey() : token;
  if (!credential) throw new Error("Falta el token de acceso de Pi.");
  const headers = new Headers(options.headers);
  headers.set("Accept", "application/json");
  headers.set("Authorization", `${auth === "key" ? "Key" : "Bearer"} ${credential}`);
  if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  const response = await fetch(`${PI_API_BASE}${path}`, {
    ...options,
    cache: "no-store",
    headers,
  });
  const text = await response.text();
  let data: unknown = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    const detail = typeof data === "object" && data && "message" in data ? String((data as {message: unknown}).message) : `Pi Platform API respondió ${response.status}`;
    throw new Error(detail);
  }
  return data as T;
}

export async function verifyPiAccessToken(accessToken: string) {
  return piFetch<{ uid: string; username?: string; wallet_address?: string }>("/me", {}, "bearer", accessToken);
}

export async function getPiPayment(paymentId: string) {
  return piFetch<{
    identifier: string; user_uid: string; amount: number; memo: string;
    metadata: Record<string, unknown>; direction: string;
    status: { developer_approved: boolean; transaction_verified: boolean; developer_completed: boolean; cancelled: boolean; user_cancelled: boolean };
    transaction: null | { txid: string; verified: boolean };
  }>(`/payments/${encodeURIComponent(paymentId)}`);
}

export async function approvePiPayment(paymentId: string) {
  return piFetch(`/payments/${encodeURIComponent(paymentId)}/approve`, { method: "POST" });
}

export async function completePiPayment(paymentId: string, txid: string) {
  return piFetch(`/payments/${encodeURIComponent(paymentId)}/complete`, {
    method: "POST",
    body: JSON.stringify({ txid }),
  });
}

export function readBearerToken(request: Request): string | null {
  const header = request.headers.get("authorization") || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match?.[1] ?? null;
}
